function path_planning_matlab()
    %% Selección de imagen
    [file, pathf] = uigetfile({'*.jpg;*.png;*.jpeg','Imágenes (*.jpg, *.png, *.jpeg)'}, ...
                             'Selecciona la imagen Mapa1');
    if isequal(file, 0)
        disp('No se seleccionó ninguna imagen. Saliendo.');
        return;
    end
    image_path = fullfile(pathf, file);
    img = imread(image_path);

    %% Selección de los puntos de inicio y fin por clic
    figure('Name','Selecciona inicio y fin');
    imshow(img);
    title('Haz clic: primero INICIO, luego FIN');
    [x_pts, y_pts] = ginput(2);
    close;

    if numel(x_pts) ~= 2
        disp('Debes seleccionar exactamente dos puntos.');
        return;
    end
    start_pt = [x_pts(1), y_pts(1)];
    end_pt   = [x_pts(2), y_pts(2)];

    %% Detectar área de interés, construir cuadrícula de ocupación, aplicar A*
    areas = detect_areas_with_astar(img, start_pt, end_pt);
    if isempty(areas)
        disp('Error en detección o no hay camino válido.');
        return;
    end

    %% Dibujar resultado
    figure('Name','Camino encontrado');
    imshow(areas.original_image);
    hold on;
    path_cells = areas.path;
    for k = 1:(size(path_cells,1)-1)
        c1 = path_cells(k, :);
        c2 = path_cells(k+1, :);
        % Convertir de celda a píxeles (centro de la celda)
        pt1 = [(c1(2)-0.5)*areas.cell_size + areas.bounding_box(1), ...
               (c1(1)-0.5)*areas.cell_size + areas.bounding_box(2)];
        pt2 = [(c2(2)-0.5)*areas.cell_size + areas.bounding_box(1), ...
               (c2(1)-0.5)*areas.cell_size + areas.bounding_box(2)];
        plot([pt1(1), pt2(1)], [pt1(2), pt2(2)], 'g-', 'LineWidth', 2);
    end
    scatter(start_pt(1), start_pt(2), 80, 'b', 'filled');
    scatter(end_pt(1), end_pt(2), 80, 'r', 'filled');
    title('Ruta óptima (verde) sin colisiones');
    hold off;
end

function areas = detect_areas_with_astar(img, start_pt, end_pt)
    gray = rgb2gray(img);

    bw = gray > 200;
    bw = imfill(bw, 'holes');
    bw = bwareaopen(bw, 500);
    stats = regionprops(bw, 'BoundingBox', 'Area');
    if isempty(stats)
        areas = [];
        return;
    end
    [~, idx] = max([stats.Area]);
    rect = stats(idx).BoundingBox;  % [x, y, width, height]
    x0 = round(rect(1)); y0 = round(rect(2));
    w = round(rect(3)); h = round(rect(4));

    roi = imcrop(img, rect);

    gray_roi = rgb2gray(roi);
    black_mask = gray_roi < 50;  % umbral para negro

    grid_size = 8;
    cell_size = floor(w / grid_size);

    occupancy = zeros(grid_size, grid_size);
    for i = 1:grid_size
        for j = 1:grid_size
            sub = black_mask((i-1)*cell_size + 1 : min(i*cell_size, size(black_mask,1)), ...
                             (j-1)*cell_size + 1 : min(j*cell_size, size(black_mask,2)));
            if mean(sub(:)) > 0.1
                occupancy(i, j) = 1;
            end
        end
    end

    rel_start = [start_pt(1) - x0, start_pt(2) - y0];
    rel_end   = [end_pt(1) - x0,   end_pt(2) - y0];
    grid_start = [floor(rel_start(2)/cell_size) + 1, floor(rel_start(1)/cell_size) + 1];
    grid_end   = [floor(rel_end(2)/cell_size) + 1,   floor(rel_end(1)/cell_size) + 1];

    if any(grid_start < 1) || any(grid_start > grid_size) || ...
       any(grid_end < 1)   || any(grid_end > grid_size)
        disp('Inicio o fin fuera de la cuadrícula.');
        areas = [];
        return;
    end

    path = astar_matlab(grid_start, grid_end, occupancy);
    if isempty(path)
        disp('No se encontró un camino válido.');
        areas = [];
        return;
    end

    areas.original_image = img;
    areas.roi = roi;
    areas.occupancy_grid = occupancy;
    areas.start = grid_start;
    areas.end = grid_end;
    areas.cell_size = cell_size;
    areas.bounding_box = round(rect);
    areas.path = path;
end

function path = astar_matlab(start, goal, grid)
    [R, C] = size(grid);
    gridSize = [R, C];

    openSet = containers.Map;
    cameFrom = containers.Map;
    gScore = inf(R, C);
    fScore = inf(R, C);

    gScore(start(1), start(2)) = 0;
    fScore(start(1), start(2)) = heuristic(start, goal);

    key0 = sub2ind([R, C], start(1), start(2));
    openSet(num2str(key0)) = fScore(start(1), start(2));

    while ~isempty(openSet)
        keys = openSet.keys;
        vals = cell2mat(openSet.values);
        [~, idx_min] = min(vals);
        key_min = keys{idx_min};
        [r, c] = ind2sub([R, C], str2double(key_min));

        current = [r, c];
        if isequal(current, goal)
            path = reconstruct_path(cameFrom, current, start, gridSize);
            return;
        end

        remove(openSet, key_min);

        neighbors = [0 1; 1 0; 0 -1; -1 0];
        for k = 1:size(neighbors,1)
            nr = current(1) + neighbors(k,1);
            nc = current(2) + neighbors(k,2);
            if nr < 1 || nr > R || nc < 1 || nc > C
                continue;
            end
            if grid(nr, nc) == 1
                continue;
            end

            tentative_g = gScore(current(1), current(2)) + 1;
            if tentative_g < gScore(nr, nc)
                cameFrom(num2str(sub2ind([R, C], nr, nc))) = current;
                gScore(nr, nc) = tentative_g;
                fScore(nr, nc) = tentative_g + heuristic([nr, nc], goal);
                key_n = num2str(sub2ind([R, C], nr, nc));
                if ~isKey(openSet, key_n)
                    openSet(key_n) = fScore(nr, nc);
                end
            end
        end
    end

    path = [];  % no se encontró camino
end

function h = heuristic(a, b)
    h = abs(a(1)-b(1)) + abs(a(2)-b(2));
end

function path = reconstruct_path(cameFrom, current, start, gridSize)
    path = current;
    key = num2str(sub2ind(gridSize, current(1), current(2)));
    while isKey(cameFrom, key)
        prev = cameFrom(key);
        path = [prev; path];
        key = num2str(sub2ind(gridSize, prev(1), prev(2)));
    end
end
